class Demo
{
   public static void main(String arg[])throws Exception
   {
      	Runtime r=Runtime.getRuntime();
	r.exec("notepad");
	
   }
}